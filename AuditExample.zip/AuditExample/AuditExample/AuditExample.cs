﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;
using System.Data;

namespace AuditExample
{
    public partial class AuditExampleEntities
    {
        public enum AuditActions
        {
            Insert,
            Update,
            Delete
        }
        public string UserName
        {
            get;
            set;
        }
       

        private void SaveJournalChanges(object sender, EventArgs e)
        {
            ObjectContext context = (ObjectContext)sender;
            context.DetectChanges();
            IEnumerable<ObjectStateEntry> changes = context.ObjectStateManager.GetObjectStateEntries(EntityState.Added | EntityState.Deleted | EntityState.Modified);
            foreach (ObjectStateEntry stateEntryEntity in changes)
            {
                if (!stateEntryEntity.IsRelationship && stateEntryEntity.Entity != null && !(stateEntryEntity.Entity is Audit))
                {
                    DoAudit(stateEntryEntity, UserName);
                }
            }
        }

        private void DoAudit(ObjectStateEntry entry, string UserName)
        {
            AuditExampleEntities entities = new AuditExampleEntities();
            if (entry.State == EntityState.Added)
            {
                
            }
            else if (entry.State == EntityState.Deleted)
            {

            }
            else if (entry.State == EntityState.Modified)
            {
                foreach (string propName in entry.GetModifiedProperties())
                {
                    Audit audit = new Audit();
                    audit.ChangeDate = DateTime.Now;
                    audit.EntityName = entry.EntitySet.Name;
                    audit.UserName = UserName;
                    audit.OldData = Convert.ToString(entry.OriginalValues[propName]);
                    audit.NewData = Convert.ToString(entry.CurrentValues[propName]);
                    audit.State = AuditActions.Update.ToString();
                    audit.ChangedColumns = propName;
                    entities.Audits.AddObject(audit);
                }
                entities.SaveChanges();
            }
        }
    }
}