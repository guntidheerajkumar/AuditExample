﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.Reflection;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Xml;
using System.Runtime.Serialization;
using System.IO;

namespace AuditExample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                AuditExampleEntities entities = new AuditExampleEntities();
                var per =  from c in entities.People 
                              where c.PId == 1 
                              select c;

                foreach (var item in per)
                {
                    item.ChangeTracker.ChangeTrackingEnabled = true;
                    item.PersonName = "Shekar";
                    item.Address = "India";
                    item.Age = 30;
                }

                entities.UserName = "SampleUser";
                int i = entities.SaveChanges();
                if (i == 0)
                {
                    Response.Write("Nothing has changed.");
                }
            }
        }
 
    }
}
